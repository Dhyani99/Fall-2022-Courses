#How to Execute Assignment-6


Run the following commands in the same directory as the HashTable.java in the same order.
```console
javac HashTable.java
java HashTable
```

The input is taken from the words.txt file, and read line by line

When resizing the hash table we resize with the next prime number after doubling the size of the hash table.
