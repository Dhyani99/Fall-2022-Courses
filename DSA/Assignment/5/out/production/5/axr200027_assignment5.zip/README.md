#How to Execute Assignment-5


Run the following commands in the same directory as the Topological.java in the same order.
```console
javac Topological.java
java Topological
```
